// popup.js
document.addEventListener('DOMContentLoaded', function() {
    const startButton = document.getElementById('startBot');
    const stopButton = document.getElementById('stopBot');
    const statusDiv = document.getElementById('status');
    const thresholdInput = document.getElementById('threshold');
    const keywordsDiv = document.getElementById('keywords');
    const newKeywordInput = document.getElementById('newKeyword');
    const addKeywordButton = document.getElementById('addKeyword');

    let keywords = [];

    // Load saved keywords, threshold, and bot state
    chrome.storage.sync.get(['savedKeywords', 'savedThreshold', 'botRunning'], function(result) {
        if (result.savedKeywords) {
            keywords = result.savedKeywords;
            displayKeywords();
        }
        if (result.savedThreshold) {
            thresholdInput.value = result.savedThreshold;
        }
        // Restore bot state
        if (result.botRunning) {
            startButton.disabled = true;
            stopButton.disabled = false;
            setStatus('Bot is running', true);
        } else {
            startButton.disabled = false;
            stopButton.disabled = true;
        }
    });

    function displayKeywords() {
        keywordsDiv.innerHTML = '';
        if (keywords.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-message';
            emptyMessage.textContent = 'No keywords added yet. Add keywords above.';
            keywordsDiv.appendChild(emptyMessage);
            return;
        }

        keywords.forEach((keyword, index) => {
            const keywordItem = document.createElement('div');
            keywordItem.className = 'keyword-item';
            
            const keywordText = document.createElement('span');
            keywordText.textContent = keyword;
            
            const deleteButton = document.createElement('button');
            deleteButton.textContent = '✕';
            deleteButton.className = 'delete-btn';
            deleteButton.onclick = () => removeKeyword(index);
            
            keywordItem.appendChild(keywordText);
            keywordItem.appendChild(deleteButton);
            keywordsDiv.appendChild(keywordItem);
        });
    }

    function saveToStorage(botState = null) {
        let saveData = {
            savedKeywords: keywords,
            savedThreshold: parseInt(thresholdInput.value)
        };

        // Only update bot state if provided
        if (botState !== null) {
            saveData.botRunning = botState;
        }

        chrome.storage.sync.set(saveData, function() {
            console.log('Settings saved to storage');
        });
    }

    function addKeyword(keyword) {
        keyword = keyword.trim();
        if (keyword && !keywords.includes(keyword)) {
            keywords.push(keyword);
            saveToStorage();
            displayKeywords();
            setStatus('Keyword added successfully!', true);
            return true;
        } else if (keywords.includes(keyword)) {
            setStatus('Keyword already exists!', false);
        }
        return false;
    }

    function removeKeyword(index) {
        keywords.splice(index, 1);
        saveToStorage();
        displayKeywords();
        setStatus('Keyword removed successfully!', true);
    }

    function setStatus(message, success = true) {
        statusDiv.textContent = message;
        statusDiv.className = success ? 'status-success' : 'status-error';
        // Don't clear status if bot is running
        if (!message.includes('Bot is running')) {
            setTimeout(() => {
                statusDiv.textContent = '';
                statusDiv.className = '';
            }, 3000);
        }
    }

    // Event Listeners
    addKeywordButton.addEventListener('click', () => {
        const keyword = newKeywordInput.value.trim();
        if (addKeyword(keyword)) {
            newKeywordInput.value = '';
        }
    });

    newKeywordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const keyword = newKeywordInput.value.trim();
            if (addKeyword(keyword)) {
                newKeywordInput.value = '';
            }
        }
    });

    // Start bot
    startButton.addEventListener('click', async () => {
        if (keywords.length === 0) {
            setStatus('Please add at least one keyword before starting the bot', false);
            return;
        }

        const threshold = parseInt(thresholdInput.value);
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0].url.includes('linkedin.com')) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'START_BOT',
                    config: {
                        threshold: threshold,
                        keywords: keywords
                    }
                });
                startButton.disabled = true;
                stopButton.disabled = false;
                saveToStorage(true); // Save bot running state
                setStatus('Bot is running', true);
            } else {
                setStatus('Please navigate to LinkedIn first', false);
            }
        });
    });

    // Stop bot
    stopButton.addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0].url.includes('linkedin.com')) {
                chrome.tabs.sendMessage(tabs[0].id, {action: 'STOP_BOT'});
                startButton.disabled = false;
                stopButton.disabled = true;
                saveToStorage(false); // Save bot stopped state
                setStatus('Bot stopped', true);
            }
        });
    });
});

// content.js
let isRunning = false;
let processedPosts = new Set();
let postsLiked = 0;
let lastScrollHeight = 0;
let noNewContentCount = 0;

// Check initial bot state when content script loads
chrome.storage.sync.get(['botRunning'], function(result) {
    if (result.botRunning) {
        isRunning = true;
        chrome.storage.sync.get(['savedKeywords', 'savedThreshold'], function(config) {
            if (config.savedKeywords && config.savedThreshold) {
                processPosts({
                    keywords: config.savedKeywords,
                    threshold: config.savedThreshold
                });
            }
        });
    }
});

function updateStatus(message, success = true) {
    chrome.runtime.sendMessage({
        type: 'STATUS_UPDATE',
        message: message,
        success: success
    });
    console.log(`Status Update: ${message}`);
}

// Rest of your content.js code remains the same...

// Add this to handle page refresh/close
window.addEventListener('beforeunload', function() {
    if (isRunning) {
        chrome.storage.sync.set({ botRunning: false });
    }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message:', request.action);
    
    if (request.action === 'START_BOT') {
        console.log('Bot starting...');
        isRunning = true;
        processPosts(request.config);
    } else if (request.action === 'STOP_BOT') {
        console.log('Bot stopping...');
        isRunning = false;
        chrome.storage.sync.set({ botRunning: false });
        updateStatus('Bot stopped', false);
    }
    
    return true;
});