chrome.runtime.onInstalled.addListener(() => {
    console.log('LinkedIn Job Finder Extension installed');
  });