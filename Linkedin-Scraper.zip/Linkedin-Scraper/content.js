// content.js
let isRunning = false;
let processedPosts = new Set();
let postsLiked = 0;
let lastScrollHeight = 0;
let noNewContentCount = 0;

// Send status updates to popup
function updateStatus(message, success = true) {
    chrome.runtime.sendMessage({
        type: 'STATUS_UPDATE',
        message: message,
        success: success
    });
    console.log(`Status Update: ${message}`); // Debug logging
}

function getPostText(post) {
    return post.textContent || '';
}

function matchWithKeywords(postText, keywords, threshold) {
    return keywords.some(keyword => {
        const similarity = postText.toLowerCase().includes(keyword.toLowerCase());
        return similarity ? threshold : 0;
    });
}

async function likePost(post) {
    try {
        const likeButton = post.querySelector('button[aria-label*="Like"], button[aria-label*="React"]');
        if (likeButton) {
            const isAlreadyLiked = likeButton.getAttribute('aria-pressed') === 'true';
            
            if (!isAlreadyLiked) {
                likeButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await new Promise(resolve => setTimeout(resolve, 1000));
                likeButton.click();
                console.log('Post liked successfully');
                postsLiked++;
                updateStatus(`Posts liked: ${postsLiked}`);
                return true;
            }
        }
    } catch (error) {
        console.error('Error liking post:', error);
        updateStatus('Error liking post', false);
    }
    return false;
}

async function scrollPage() {
    if (!isRunning) return; // Check if bot should still be running

    const currentHeight = document.documentElement.scrollHeight;
    
    if (currentHeight === lastScrollHeight) {
        noNewContentCount++;
        if (noNewContentCount >= 3) {
            window.scrollTo(0, 0);
            noNewContentCount = 0;
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    } else {
        noNewContentCount = 0;
    }
    
    window.scrollBy(0, 500);
    lastScrollHeight = currentHeight;
    
    console.log('Scrolled page');
    return new Promise(resolve => setTimeout(resolve, 2000));
}

async function processPosts(config) {
    updateStatus('Bot started. Processing posts...');
    
    while (isRunning) {
        try {
            if (!isRunning) break; // Check if bot should stop

            const posts = document.querySelectorAll('.feed-shared-update-v2, .occludable-update');
            console.log(`Found ${posts.length} posts`);
            
            for (const post of posts) {
                if (!isRunning) break; // Check if bot should stop
                
                const postId = post.getAttribute('data-urn') || post.id;
                if (!postId || processedPosts.has(postId)) continue;
                
                const postText = getPostText(post);
                console.log('Processing post:', postText.substring(0, 100));
                
                if (matchWithKeywords(postText, config.keywords, config.threshold)) {
                    console.log('Found matching post');
                    if (await likePost(post)) {
                        processedPosts.add(postId);
                        await new Promise(resolve => setTimeout(resolve, 2000));
                    }
                }
                
                processedPosts.add(postId);
            }
            
            if (isRunning) {
                await scrollPage();
            }
            
        } catch (error) {
            console.error('Error processing posts:', error);
            updateStatus('Error processing posts', false);
            if (!isRunning) break;
        }
    }
    
    updateStatus('Bot stopped', false);
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message:', request.action); // Debug logging
    
    if (request.action === 'START_BOT') {
        console.log('Bot starting...');
        isRunning = true;
        processPosts(request.config);
    } else if (request.action === 'STOP_BOT') {
        console.log('Bot stopping...');
        isRunning = false;
        updateStatus('Bot stopped', false);
    }
    
    // Always return true for async response
    return true;
});

// Initialize when the page loads
console.log('Content script loaded');

// popup.js
document.addEventListener('DOMContentLoaded', function() {
    const startButton = document.getElementById('startBot');
    const stopButton = document.getElementById('stopBot');
    const statusDiv = document.getElementById('status');
    const thresholdInput = document.getElementById('threshold');
    const keywordsDiv = document.getElementById('keywords');
    const newKeywordInput = document.getElementById('newKeyword');
    const addKeywordButton = document.getElementById('addKeyword');

    stopButton.disabled = true;
    let keywords = [];

    // Load saved keywords and threshold
    chrome.storage.sync.get(['savedKeywords', 'savedThreshold'], function(result) {
        if (result.savedKeywords) {
            keywords = result.savedKeywords;
            displayKeywords();
        }
        if (result.savedThreshold) {
            thresholdInput.value = result.savedThreshold;
        }
    });

    function displayKeywords() {
        keywordsDiv.innerHTML = '';
        if (keywords.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-message';
            emptyMessage.textContent = 'No keywords added yet. Add keywords above.';
            keywordsDiv.appendChild(emptyMessage);
            return;
        }

        keywords.forEach((keyword, index) => {
            const keywordItem = document.createElement('div');
            keywordItem.className = 'keyword-item';
            
            const keywordText = document.createElement('span');
            keywordText.textContent = keyword;
            
            const deleteButton = document.createElement('button');
            deleteButton.textContent = '✕';
            deleteButton.className = 'delete-btn';
            deleteButton.onclick = () => removeKeyword(index);
            
            keywordItem.appendChild(keywordText);
            keywordItem.appendChild(deleteButton);
            keywordsDiv.appendChild(keywordItem);
        });
    }

    function saveToStorage() {
        chrome.storage.sync.set({
            savedKeywords: keywords,
            savedThreshold: parseInt(thresholdInput.value)
        }, function() {
            console.log('Settings saved to storage');
        });
    }

    function addKeyword(keyword) {
        keyword = keyword.trim();
        if (keyword && !keywords.includes(keyword)) {
            keywords.push(keyword);
            saveToStorage(); // Save immediately after adding
            displayKeywords();
            setStatus('Keyword added successfully!', true);
            return true;
        } else if (keywords.includes(keyword)) {
            setStatus('Keyword already exists!', false);
        }
        return false;
    }

    function removeKeyword(index) {
        keywords.splice(index, 1);
        saveToStorage(); // Save immediately after removing
        displayKeywords();
        setStatus('Keyword removed successfully!', true);
    }

    function setStatus(message, success = true) {
        statusDiv.textContent = message;
        statusDiv.className = success ? 'status-success' : 'status-error';
        setTimeout(() => {
            statusDiv.textContent = '';
            statusDiv.className = '';
        }, 3000);
    }

    // Event Listeners
    addKeywordButton.addEventListener('click', () => {
        const keyword = newKeywordInput.value.trim();
        if (addKeyword(keyword)) {
            newKeywordInput.value = '';
        }
    });

    newKeywordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const keyword = newKeywordInput.value.trim();
            if (addKeyword(keyword)) {
                newKeywordInput.value = '';
            }
        }
    });

    // Start bot
    startButton.addEventListener('click', async () => {
        if (keywords.length === 0) {
            setStatus('Please add at least one keyword before starting the bot', false);
            return;
        }

        const threshold = parseInt(thresholdInput.value);
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0].url.includes('linkedin.com')) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'START_BOT',
                    config: {
                        threshold: threshold,
                        keywords: keywords
                    }
                });
                startButton.disabled = true;
                stopButton.disabled = false;
                setStatus('Bot started successfully!', true);
            } else {
                setStatus('Please navigate to LinkedIn first', false);
            }
        });
    });

    // Stop bot
    stopButton.addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0].url.includes('linkedin.com')) {
                chrome.tabs.sendMessage(tabs[0].id, {action: 'STOP_BOT'});
                startButton.disabled = false;
                stopButton.disabled = true;
                setStatus('Bot stopped', true);
            }
        });
    });

    // Listen for status updates from content script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'STATUS_UPDATE') {
            setStatus(message.message, message.success);
        }
    });
});